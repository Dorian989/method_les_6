import scrapy
from scrapy.http import HtmlResponse
from lerua_1.lerua_1.items import Lerua1Item
from scrapy.loader import ItemLoader


# //uc-plp-item-new/a[@slot= "name"] название

class LeruaMerSpider(scrapy.Spider):
    name = 'lerua_mer'
    allowed_domains = ['leroymerlin.ru']
    start_urls = ['http://leroymerlin.ru/']

    def __init__(self, mark):
        self.start_urls = [f'https://leroymerlin.ru/offer/tovary-dlya-uyuta-v-dome/?plpView=largeCard{mark}']

    def parse(self, response: HtmlResponse):
        ads_links = response.xpath(('//uc-plp-item-new/a[@href]')).extract()
        for link in ads_links:
            yield response.follow(link, callback=self.parse_ads)

    def parse_ads(self, response: HtmlResponse):
        name = response.css('plp-item__info__title::text').extract_first()
        product_link = response.xpath('//uc-plp-item-new/a[@href]')
        photos = response.xpath('//img[@alt= "main-photo"]').extract()
        price = response.xpath('//uc-plp-item-price[@slot= "price"]').extract()
        yield Lerua1Item(name=name, product_link=product_link, photos=photos, price=price)
        print(name, product_link, photos, price)