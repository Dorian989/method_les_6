from scrapy.crawler import CrawlerProcess
from scrapy.settings import Settings

from lerua_1.lerua_1.spiders.lerua_mer import LeruaMerSpider
from lerua_1.lerua_1 import settings

if __name__ == '__main__':
    crawler_settings = Settings()
    crawler_settings.setmodule(settings)
    process = CrawlerProcess(settings=crawler_settings)
    process.crawl(LeruaMerSpider, mark='ТОВАРЫ ДЛЯ УЮТА В ДОМЕ')
